// 程序入口
import Vector3 = Laya.Vector3;
class LayaAir3D {
    constructor() {
        //初始化Laya引擎
        this.initLaya();
       
        new course.C2_6();
        
    }


    private initLaya():void{
        //初始化引擎
        Laya3D.init(0, 0, true);
        //适配模式
        Laya.stage.scaleMode = Laya.Stage.SCALE_FULL;
        Laya.stage.screenMode = Laya.Stage.SCREEN_NONE;

        GlobalVar.scene3D = new sandi.container.Scene3D();
    }

}
new LayaAir3D();