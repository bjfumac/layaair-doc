/*
* name;
*/
class GlobalVar{
    public static scene3D:sandi.container.Scene3D;
    constructor(){

    }
}