/**
* name 
*/
module sandi.script{
	import Sprite3D = Laya.Sprite3D;
	export class LabelScript extends Laya.Script{
		private label:Laya.Label;
		public camera:Laya.Camera;
		public color:string = "#ffffff";
		private gameObject:Sprite3D
		constructor(){
			super();
		}

		public _load(owner:Sprite3D):void{
			this.gameObject = owner;
            
		}
		
		public _start(state:Laya.RenderState):void{
			this.createLabel();     
		}

		public _update(state:Laya.RenderState):void{
			let screenPos = new Vector3();
			this.camera.worldToViewportPoint(this.gameObject.transform.position, screenPos);
			this.label.x = screenPos.x;
			this.label.y = screenPos.y;
			this.label.text = "x="+this.gameObject.transform.position.x+",y="+this.gameObject.transform.position.y+",z="+this.gameObject.transform.position.z;
		}

		public createLabel():void{
			this.label = new Laya.Label();
			this.label.color = this.color;
			this.label.fontSize = 20;
			Laya.stage.addChild(this.label);
		}

	}
}