/**
* name Mac
*/
module sandi.script{
	import Vector3 = Laya.Vector3;
    import Vector2 = Laya.Vector2;
    import Sprite3D = Laya.Sprite3D;
    import Event = Laya.Event;
	export class FreeCameraScript extends Laya.Script{
    	public static kUpDirection = new Vector3(0.0, 1.0, 0.0); 
		public moveSpeed:number = 0.01;  
		public rotateSpeed:number = 0.08;  
		private lastMousePosX:number = 0.0;  
		private lastMousePosY:number = 0.0;  
		private mouseRightKeyDown:boolean = false;  
        private currentKey:number = -1;
        private currentRMouse:number = 0;
        private gameObject:Sprite3D;
		constructor(){
			super();
		}

		public _load(owner:Laya.Sprite3D):void{
            this.gameObject = owner;
		}
		
		public _start(state:Laya.RenderState):void{
            Laya.stage.on(Event.KEY_DOWN,this,this.onKeyDown);
            Laya.stage.on(Event.KEY_UP,this,this.onKeyUp);
            Laya.stage.on(Event.RIGHT_MOUSE_DOWN,this,this.onRMouseDown);
            Laya.stage.on(Event.RIGHT_MOUSE_UP,this,this.onRMouseUp);
            
		}

        private onKeyDown(ev:Event):void{
            this.currentKey = ev.keyCode;
        }

        private onKeyUp(ev:Event):void{
            this.currentKey = -1;
        }

        private onRMouseDown():void{
            this.currentRMouse = 1;
        }

        private onRMouseUp():void{
            this.currentRMouse = 0;
        }

	public _update(state:Laya.RenderState):void{
        if (this.currentRMouse == 1)  
        {  
            if (this.mouseRightKeyDown == false)  
            {  
                this.mouseRightKeyDown = true;  
                this.lastMousePosX = Laya.stage.mouseX;  
                this.lastMousePosY = Laya.stage.mouseY;  
            } 
            else{
                let fDeltaX = Laya.stage.mouseX - this.lastMousePosX;  
                let fDeltaY = Laya.stage.mouseY - this.lastMousePosY;  
                this.lastMousePosX = Laya.stage.mouseX;  
                this.lastMousePosY = Laya.stage.mouseY;  
  
  
                let kNewEuler = this.gameObject.transform.localRotationEuler;  
                kNewEuler.x -= (fDeltaY * this.rotateSpeed);  
                kNewEuler.y -= (fDeltaX * this.rotateSpeed);  
                this.gameObject.transform.localRotationEuler = kNewEuler;  
            }
        }  
        else if (this.currentRMouse == 0) 
        {  
            if (this.mouseRightKeyDown == true)  
            {  
                this.mouseRightKeyDown = false;  
                this.lastMousePosX = 0;  
                this.lastMousePosY = 0;  
            }  
        }  

        let fMoveDeltaX = 0.0;  
        let fMoveDeltaY = 0.0;  
        let fMoveDeltaZ = 0.0;  
        let fDeltaTime = Laya.timer.delta; 
        if (this.currentKey == Laya.Keyboard.A)  
        {  
            fMoveDeltaX -= this.moveSpeed * fDeltaTime;  
        }  
        if (this.currentKey == Laya.Keyboard.D)  
        {  
            fMoveDeltaX += this.moveSpeed * fDeltaTime;  
        }  
        if (this.currentKey == Laya.Keyboard.W)  
        {  
            fMoveDeltaY += this.moveSpeed * fDeltaTime;  
        }  
        if (this.currentKey == Laya.Keyboard.S)  
        {  
            fMoveDeltaY -= this.moveSpeed * fDeltaTime;  
        }  
        if (this.currentKey == Laya.Keyboard.NUMBER_1)  
        {  
            fMoveDeltaZ += this.moveSpeed * fDeltaTime;  
        }  
        if (this.currentKey == Laya.Keyboard.NUMBER_2)  
        {  
            fMoveDeltaZ -= this.moveSpeed * fDeltaTime;  
        }  
        if (fMoveDeltaX != 0.0 || fMoveDeltaY != 0.0 || fMoveDeltaZ != 0.0)  
        {  
            let kForward = this.gameObject.transform.forward;  
            let kRight = new Vector3();
            let kUp = new Vector3();
            Vector3.cross(FreeCameraScript.kUpDirection, kForward, kRight);  
            Vector3.cross(kRight,kForward, kUp);
            let kNewPos = this.gameObject.transform.position;  
            let temp = new Vector3();
            Vector3.scale(kRight,fMoveDeltaX,temp);
            Vector3.subtract(kNewPos,temp,kNewPos);

            Vector3.scale(kUp,fMoveDeltaY,temp);
            Vector3.subtract(kNewPos,temp,kNewPos);

            Vector3.scale(kForward,fMoveDeltaZ,temp);
            Vector3.add(kNewPos,temp,kNewPos);
            this.gameObject.transform.position = kNewPos;  
        }  
    }
}
	}