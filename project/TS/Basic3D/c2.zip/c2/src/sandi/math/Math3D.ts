/**
* name 
*/
module sandi.math{
	export class Math3D{
		constructor(){

		}

		public static QuaternionFromToRotation(from:Vector3,to:Vector3):Laya.Quaternion{
			let dot = Vector3.dot(from, to);
			let cross = new Vector3();
			let w = new Vector3();
			Vector3.cross(from,to,cross);
			let m = Math.sqrt(2 + 2 * dot);
			Vector3.scale(cross, 1/m, w);
			return new Laya.Quaternion(0.5 * m, w.x, w.y, w.z);
		}
	}
}