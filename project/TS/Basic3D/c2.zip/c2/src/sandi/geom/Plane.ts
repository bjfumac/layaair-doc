/**
* name 
*/
module sandi.geom{
	import MeshSprite3D = Laya.MeshSprite3D;
	import Sprite3D = Laya.Sprite3D;
	import Vector3 = Laya.Vector3;
	import Vector4 = Laya.Vector4;
	import BoxMesh = Laya.BoxMesh;
	import Color = sandi.data.Color;
	export class Plane extends Sprite3D{
		constructor(){
			super();
		}

		public static create(position:Vector3,normal:Vector3 = Vector3.Up, color:Color = Color.WHITE, showLabel:boolean = false):Plane{
			let sub = new MeshSprite3D(new BoxMesh(40,40,0.1));
			var material:Laya.StandardMaterial = new Laya.StandardMaterial();
			material.renderMode=Laya.StandardMaterial.RENDERMODE_ADDTIVE;
			material.specularColor = Vector4.ZERO;
			material.albedoColor = color.toVector4();
			sub.meshRender.material = material;
			let plane = new Plane();
			plane.addChild(sub);
			plane.transform.position = position;
			let rot = sandi.math.Math3D.QuaternionFromToRotation(normal,Vector3.Up);
			plane.transform.localRotation = rot;
			if(showLabel){
				let script = plane.addComponent(sandi.script.LabelScript) as sandi.script.LabelScript;
				script.color = color.toHex();
				script.camera = sandi.container.Scene3D.mainCamera;
			}
			return plane;
		}

		
	}
}