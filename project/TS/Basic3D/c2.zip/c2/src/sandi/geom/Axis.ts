/**
* name 
*/
module sandi.geom{
	import Sprite3D = Laya.Sprite3D;
	import Vector3 = Laya.Vector3;
	import Color = sandi.data.Color;
	export class Axis extends Sprite3D{
		constructor(){
			super();
			this.init();
		}

		private init():void{
			let axisX = Line.create(Vector3.ZERO,new Vector3(10,0,0),Color.RED);
			this.addChild(axisX);
			let axisY = Line.create(Vector3.ZERO,new Vector3(0,10,0),Color.YELLOW);
			this.addChild(axisY);
			let axisZ = Line.create(Vector3.ZERO,new Vector3(0,0,10),Color.BLUE);
			this.addChild(axisZ);

		}
	}
}