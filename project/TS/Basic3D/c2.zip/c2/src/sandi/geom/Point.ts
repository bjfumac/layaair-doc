/**
* name 
*/
module sandi.geom{
	import MeshSprite3D = Laya.MeshSprite3D;
	import Sprite3D = Laya.Sprite3D;
	import SphereMesh = Laya.SphereMesh
	import BaseMesh = Laya.BaseMesh;
	import Vector3 = Laya.Vector3;
	import Vector4 = Laya.Vector4;
	import Color = sandi.data.Color;
	export class Point extends Sprite3D{
		constructor(){
			super();
		}

		public static create(pos:Vector3, color:Color = Color.WHITE, showLabel:boolean = false):Point{
			let point = new Point();
			let sub = new MeshSprite3D(new SphereMesh(0.2));
			point.addChild(sub);
			point.transform.localPosition = pos;
			var material:Laya.StandardMaterial = new Laya.StandardMaterial();
			material.renderMode=Laya.StandardMaterial.RENDERMODE_ADDTIVE;
			material.specularColor = Vector4.ZERO;
			material.albedoColor = color.toVector4();
			sub.meshRender.material = material;
			if(showLabel){
				let script = point.addComponent(sandi.script.LabelScript) as sandi.script.LabelScript;
				script.color = color.toHex();
				script.camera = sandi.container.Scene3D.mainCamera;
			}
			return point;
		}
	}

}