/**
* name 
*/
module sandi.geom{
	import MeshSprite3D = Laya.MeshSprite3D;
	import Sprite3D = Laya.Sprite3D;
	import Vector3 = Laya.Vector3;
	import Vector4 = Laya.Vector4;
	import Color = sandi.data.Color;
	import CylinderMesh = Laya.CylinderMesh;
	import BaseMesh = Laya.BaseMesh;
	export class Line extends Sprite3D{
		private meshContainer:Sprite3D;
		constructor(){
			super();
			this.meshContainer = new Sprite3D();
			this.addChild(this.meshContainer);
		}

		public static create(from:Vector3, to:Vector3, color:Color = Color.WHITE, showLabel:boolean = false):Line{
			let dir = new Vector3();
			Vector3.subtract(to,from,dir);
			let len = Vector3.distance(from,to);
			let sub = new MeshSprite3D(new CylinderMesh(0.1,len));
			sub.transform.rotate(new Vector3(90,0,0),true,false);
			sub.transform.localPosition = new Vector3(0,0,-len/2);
			var material:Laya.StandardMaterial = new Laya.StandardMaterial();
			material.renderMode=Laya.StandardMaterial.RENDERMODE_ADDTIVE;
			material.specularColor = Vector4.ZERO;
			material.albedoColor = color.toVector4();
			sub.meshRender.material = material;
			let line = new Line();
			line.meshContainer.addChild(sub);
			line.transform.position = from;
			let towardPos = new Vector3();
			Vector3.scale(dir,len<<2, towardPos);
			//Vector3.add(line.transform.position, towardPos, towardPos);
			line.meshContainer.transform.lookAt(towardPos, Vector3.Up, false);
			if(showLabel){
				let script = line.addComponent(sandi.script.LabelScript) as sandi.script.LabelScript;
				script.color = color.toHex();
				script.camera = sandi.container.Scene3D.mainCamera;
			}
			return line;
		}
	}
}