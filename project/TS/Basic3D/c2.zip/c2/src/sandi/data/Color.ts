/**
* name 
*/
module sandi.data{
	import Vector3 = Laya.Vector3;
	import Vector4 = Laya.Vector4;
	export class Color{
		public static readonly RED:Color = new Color(255,0,0);
		public static readonly GREEN:Color = new Color(0,255,0);
		public static readonly BLUE:Color = new Color(0,0,255);
		public static readonly WHITE:Color = new Color(255,255,255);
		public static readonly BLACK:Color = new Color(0,0,0);
		public static readonly YELLOW:Color = new Color(255,255,0);
		public red:number;
		public green:number;
		public blue:number;
		public alpha:number;
		constructor(red:number = 255, green:number = 255, blue:number = 255, alpha = 255){
			this.red = red;
			this.green = green;
			this.blue =blue;
			this.alpha = alpha / 255;
		}

		public toVector4():Vector4{
			return new Vector4(this.red, this.green, this.blue, this.alpha);
		}

		public toVector3():Vector3{
			return new Vector3(this.red, this.green, this.blue);
		}

		public toHex():string{
			let redStr = this.red.toString(16);
			redStr = redStr.length == 1?"0"+redStr:redStr;
			let greenStr = this.green.toString(16);
			greenStr = greenStr.length == 1?"0"+greenStr:greenStr;
			let blueStr = this.blue.toString(16);
			blueStr = blueStr.length == 1?"0"+blueStr:redStr;
			return "#"+redStr+greenStr+blueStr;
		}
	}
}