/**
* name 
*/
module sandi.container{
	export class Scene3D extends Laya.Scene{
		public static mainCamera:Laya.Camera;
		constructor(){
			super();
			this.initScene();
		}

		private initScene():void{
			//添加照相机
			var camera: Laya.Camera = (this.addChild(new Laya.Camera(0, 0.1, 100))) as Laya.Camera;
			camera.transform.translate(new Laya.Vector3(0, 0, 30));
			//camera.transform.rotate(new Laya.Vector3(-30, 0, 0), true, false);
			camera.clearColor = null;
			camera.addComponent(sandi.script.FreeCameraScript);
			Scene3D.mainCamera = camera;
			//添加方向光
			var directionLight: Laya.DirectionLight = this.addChild(new Laya.DirectionLight()) as Laya.DirectionLight;
			directionLight.color = new Laya.Vector3(0.6, 0.6, 0.6);
			directionLight.transform.worldMatrix.setForward(new Laya.Vector3(1, -1, 0));

			let axis = new sandi.geom.Axis();
        	this.addChild(axis);
			Laya.stage.addChild(this);
			
		}
	}
}