/**
* name 
*/
module course{
	export class C2_5{
		constructor(){
			this.makeMatrix();
			this.makeIdentityMatrix();
			this.add();
			this.scalarMul();
			this.mul();
		}

		//创建矩阵
		private makeMatrix():void{
			let a = new Laya.Matrix4x4(
				1,3,5,7,
				9,11,13,15,
				17,19,21,23,
				25,27,29,31
			);
			console.log(a.elements);
		}

		//创建单位矩阵
		private makeIdentityMatrix():void{
			let i = new Laya.Matrix4x4();
			i.identity();
			console.log(i.elements);
		}

		//矩阵加减法
		private add():void{
			let a = new Laya.Matrix4x4(
				1,3,5,7,
				9,11,13,15,
				17,19,21,23,
				25,27,29,31
			);
			let b = new Laya.Matrix4x4(
				2,4,6,8,
				10,12,14,16,
				18,20,22,24,
				26,28,30,24
			);
			let result = new Laya.Matrix4x4();
			for(let i=0;i<16;i++){
				//加法
				result.elements[i] = a.elements[i]+b.elements[i];
				//减法
				//c.elements[i] = a.elements[i]-b.elements[i];
			}
			console.log(result.elements);			
		}

		//标量乘法
		private scalarMul():void{
			let a = new Laya.Matrix4x4(
				1,3,5,7,
				9,11,13,15,
				17,19,21,23,
				25,27,29,31
			);
			let c = 10;
			let result = new Laya.Matrix4x4();
			for(let i=0;i<16;i++){
				//加法
				result.elements[i] = a.elements[i] * c;
			}
			console.log(result.elements);	
		}

		//矩阵乘法
		private mul():void{
			let a = new Laya.Matrix4x4(
				1,3,5,7,
				9,11,13,15,
				17,19,21,23,
				25,27,29,31
			);
			let b = new Laya.Matrix4x4(
				2,4,6,8,
				10,12,14,16,
				18,20,22,24,
				26,28,30,24
			);
			let result = new Laya.Matrix4x4();
			Laya.Matrix4x4.multiply(a,b,result);
			console.log(result.elements);
		}
		
		
	}
}