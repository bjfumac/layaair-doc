/**
* name 
*/
module course{
	export class C2_6{
		constructor(){
			this.transformVector4();
			this.transformVector3();
			this.rotation();
			this.scaling();
			this.translation();
		}


		//整合缩放、旋转、平移变换
		private transformVector4():void{
			let rotX = new Laya.Matrix4x4();
			let rotY = new Laya.Matrix4x4();
			let rotZ = new Laya.Matrix4x4();
			let scale = new Laya.Matrix4x4();
			let trans = new Laya.Matrix4x4();
			let finalMtx = new Laya.Matrix4x4();
			//延三个轴分别旋转90度
			Laya.Matrix4x4.createRotationX(0.785, rotX);
			Laya.Matrix4x4.createRotationX(0.785, rotY);
			Laya.Matrix4x4.createRotationX(0.785, rotZ);
			//放大一倍
			Laya.Matrix4x4.createScaling(new Vector3(1,1,1), scale);
			//平移(20,10,20)
			Laya.Matrix4x4.createTranslate(new Vector3(20,10,20), trans);
			//利用矩阵乘法合并几个矩阵操作，注意顺序则不同结果不同。
			Laya.Matrix4x4.multiply(rotX,rotY, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,rotZ, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,scale, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,trans, finalMtx);
			let result = new Laya.Vector4();
			let v = new Laya.Vector4(1,2,3,1);
			Laya.Vector4.transformByM4x4(v,finalMtx,result);
			console.log(result.elements);
		}
		
		//整合缩放、旋转、平移变换,与transformVector4结果相同，因为transformVector4采用齐次坐标
		private transformVector3():void{
			let rotX = new Laya.Matrix4x4();
			let rotY = new Laya.Matrix4x4();
			let rotZ = new Laya.Matrix4x4();
			let scale = new Laya.Matrix4x4();
			let trans = new Laya.Matrix4x4();
			let finalMtx = new Laya.Matrix4x4();
			//延三个轴分别旋转90度
			Laya.Matrix4x4.createRotationX(0.785, rotX);
			Laya.Matrix4x4.createRotationX(0.785, rotY);
			Laya.Matrix4x4.createRotationX(0.785, rotZ);
			//放大一倍
			Laya.Matrix4x4.createScaling(new Vector3(1,1,1), scale);
			//平移(20,10,20)
			Laya.Matrix4x4.createTranslate(new Vector3(20,10,20), trans);
			//利用矩阵乘法合并几个矩阵操作，注意顺序则不同结果不同。
			//利用矩阵乘法合并几个矩阵操作，注意顺序则不同结果不同。
			//result = v*(rotX*rotY*rotZ*scale*trans) 
			//操作顺序：先旋转后缩放最后平移
			Laya.Matrix4x4.multiply(rotX,rotY, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,rotZ, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,scale, finalMtx);
			Laya.Matrix4x4.multiply(finalMtx,trans, finalMtx);
			let result = new Laya.Vector4();
			//没有采用齐次坐标
			let v = new Laya.Vector3(1,2,3);
			//进行这个计算时底层会自动把v齐次化再进行计算，即将(1,2,3)转化为(1,2,3,1)
			Vector3.transformV3ToV4(v,finalMtx,result);
			console.log(result.elements);
		}

		//旋转矩阵
		private rotation():void{
			let result = new Laya.Matrix4x4();
			//x轴，第一个参数为弧度
			Laya.Matrix4x4.createRotationX(3.1415, result);
			//y轴，第一个参数为弧度
			//Laya.Matrix4x4.createRotationY(3.1415, result);
			//z轴，第一个参数为弧度
			//Laya.Matrix4x4.createRotationZ(3.1415, result);
			console.log(result.elements);
		}

		//缩放矩阵
		private scaling():void{
			let result = new Laya.Matrix4x4();
			//1,2,3分别表示x，y，z轴的缩放量
			let scale = new Vector3(2,1,2);
			Laya.Matrix4x4.createScaling(scale, result);
			console.log(result.elements);
		}

		//平移矩阵
		private translation():void{
			let result = new Laya.Matrix4x4();
			//1,2,3分别表示x，y，z轴的缩放量
			let translate = new Vector3(2,1,2);
			Laya.Matrix4x4.createTranslate(translate, result);
			console.log(result.elements);
		}

		private combine():void{

		}

	}
}