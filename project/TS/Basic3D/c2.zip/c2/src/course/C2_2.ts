/**
* name 
*/
module course{
	export class C2_2{
		constructor(){
			this.makeVector();
			this.mag();	
			this.unit();		
			this.unit1();		
		}

		//创建向量
		private makeVector():void{
			let v = new Vector3(1,2,3);
			console.log(v);
		}

		//模计算
		private mag():void{
			let v = new Vector3(1,1,1);
			let length = Vector3.scalarLength(v);
			console.log(length);
		}

		//单位向量计算
		private unit():void{
			let result = new Vector3();
			let v = new Vector3(10,20,30);
			let magn = Vector3.scalarLength(v);
			result.x = v.x / magn;
			result.y = v.y / magn;
			result.z = v.z / magn;
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		//单位向量计算（内置api实现）
		private unit1():void{
			let result = new Vector3();
			let v = new Vector3(10,20,30);
			Vector3.normalize(v,result);
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		
		
	}
}