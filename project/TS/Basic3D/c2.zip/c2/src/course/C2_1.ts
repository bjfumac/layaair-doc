/**
* name 
*/
module course{
	export class C2_1{
		constructor(){
			this.drawPlane();
		}

		//绘制平面
		private drawPlane():void{
			let plane = sandi.geom.Plane.create(new Vector3(0,0,0),Vector3.UnitY,new sandi.data.Color(255,255,255,128));
			GlobalVar.scene3D.addChild(plane);
		}

	}
}