/**
* name 
*/
module course{
	export class C2_3{
		constructor(){
			this.add();
			this.add1();
			this.sub();
			this.commLow();
			this.scalarMul();
		}

		//加法
		private add():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			result.x = a.x+b.x;
			result.y = a.y+b.y;
			result.z = a.z+b.z;
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		//加法（内置api实现）
		private add1():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			Vector3.add(a,b,result);
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);

		}

		//减法
		private sub():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			result.x = a.x-b.x;
			result.y = a.y-b.y;
			result.z = a.z-b.z;
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		//减法（内置api实现）
		private sub1():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			Vector3.subtract(a,b,result);
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		//交换律
		private commLow():void{
			let resultAB = new Vector3();
			let resultBA = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			Vector3.add(a,b,resultAB);
			console.log("x:"+resultAB.x+",y:"+resultAB.y+",z:"+resultAB.z);
			Vector3.add(b,a,resultBA);
			console.log("x:"+resultBA.x+",y:"+resultBA.y+",z:"+resultBA.z);
			let eq = Vector3.equals(resultAB, resultBA);
			console.log(eq);
		}

		//标量乘法
		private scalarMul():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = 10;
			Vector3.scale(a,b,result);
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		
	}
}