/**
* name 
*/
module course{
	export class C2_4{
		constructor(){
			this.dot();
			this.dot1();
			this.cross();
			this.cross1();
		}

		//点乘
		private dot():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			Vector3.multiply(a,b,result);
			console.log(result.x+result.y+result.z);
		}

		//点乘（内置api实现）
		private dot1():void{
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			let result = Vector3.dot(a,b);
			console.log(result);
		}

		//叉乘（内置api实现）
		private cross():void{
			let result = new Vector3();
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			Vector3.cross(a,b,result);
			console.log("x:"+result.x+",y:"+result.y+",z:"+result.z);
		}

		//叉乘
		private cross1():void{
			let a = new Vector3(1,3,5);
			let b = new Vector3(2,4,8);
			let cx = a.y*b.z-a.z*b.y;
			let cy = a.z*b.x-a.x*b.z;
			let cz = a.x*b.y-a.y*b.x;
			console.log("x:"+cx+",y:"+cy+",z:"+cz);
		}
	}
}